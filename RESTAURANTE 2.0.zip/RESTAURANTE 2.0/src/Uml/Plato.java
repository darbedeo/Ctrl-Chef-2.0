package Uml;

public class Plato {

    private String idPlato;

    private int cantIng;

    private int cantPlatos;

    private Double precio;

    private Object untitledField;

    private int numorden;

    public void platoMasVendido() {
    }
}
