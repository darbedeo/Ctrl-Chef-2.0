package Uml;

public class Restaurante {

    private String nombre;

    private String direccion;

    private double telefono;

    private String nomd;

    public Restaurante() {
    }
}
